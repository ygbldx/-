package com.tvmarker.app

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var overlayStatusTv: TextView
    private lateinit var accStatusTv: TextView
    private lateinit var notifStatusTv: TextView
    private lateinit var missingContainer: LinearLayout

    private val requestNotifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            refreshStatus()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.ensureChannel(this)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun dp(v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun buildUi(): ScrollView {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#121417"))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(24f), dp(18f), dp(28f))
        }

        val title = TextView(this).apply {
            text = "TV红蓝快标"
            setTextColor(Color.parseColor("#F2F4F7"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "仅在 TradingView 图表页显示红蓝圆点，切回自选表自动高速批量标色"
            setTextColor(Color.parseColor("#9AA4B2"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, dp(6f), 0, dp(18f))
        }
        root.addView(subtitle)

        // Card 1: Permissions
        val permCard = makeCard()
        permCard.addView(makeSectionTitle("1. 必备权限（全部开启即可使用）"))

        overlayStatusTv = makeStatusRow(permCard, "悬浮窗权限", "去开启") {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        accStatusTv = makeStatusRow(permCard, "无障碍服务（TV红蓝快标助手）", "去开启") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        notifStatusTv = makeStatusRow(permCard, "系统通知权限（漏项提醒）", "去开启") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                requestNotifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                }
                startActivity(intent)
            }
        }
        root.addView(permCard)

        // Card 2: Button position & vivo tip
        val opsCard = makeCard()
        opsCard.addView(makeSectionTitle("2. 悬浮圆点与 vivo 后台设置"))

        val tipText = TextView(this).apply {
            text = "• 红圆默认盖在图表左下角 TV 符号上，蓝圆在红圆右侧；长按圆点可拖动位置。
" +
                "• vivo 手机建议在「设置 → 电池 → 后台耗电管理」中将本应用设为「允许后台高耗电」，并在最近任务界面下拉锁定，防止系统回收。"
            setTextColor(Color.parseColor("#CBD5E1"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setLineSpacing(dp(4f).toFloat(), 1f)
            setPadding(0, dp(4f), 0, dp(12f))
        }
        opsCard.addView(tipText)

        val resetBtn = makeActionButton("重置红蓝按钮回 TV 符号默认位置", "#2B3240") {
            AppPrefs.resetButtonPos(this)
            TvMarkerAccessibilityService.instance?.resetFloatingButtonsToDefault()
        }
        opsCard.addView(resetBtn)
        root.addView(opsCard)

        // Card 3: Missing symbol messages
        val logCard = makeCard()
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logTitle = makeSectionTitle("3. 未找到品种提醒记录").apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val clearBtn = Button(this).apply {
            text = "清空"
            setTextColor(Color.parseColor("#9AA4B2"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                AppPrefs.clearMissingMessages(this@MainActivity)
                refreshMissingMessages()
            }
        }
        headerRow.addView(logTitle)
        headerRow.addView(clearBtn)
        logCard.addView(headerRow)

        missingContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6f), 0, 0)
        }
        logCard.addView(missingContainer)
        root.addView(logCard)

        scroll.addView(root)
        return scroll
    }

    private fun makeCard(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(14f).toFloat()
                setColor(Color.parseColor("#1C2026"))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(14f)
            }
        }
    }

    private fun makeSectionTitle(text: String): TextView {
        return TextView(this).apply {
            this.text = text
            setTextColor(Color.parseColor("#F2F4F7"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(8f))
        }
    }

    private fun makeStatusRow(
        parent: LinearLayout,
        label: String,
        btnLabel: String,
        onClick: () -> Unit
    ): TextView {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6f), 0, dp(6f))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val titleTv = TextView(this).apply {
            text = label
            setTextColor(Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        }
        val statusTv = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        }
        col.addView(titleTv)
        col.addView(statusTv)

        val btn = makeActionButton(btnLabel, "#1E88FF", onClick).apply {
            layoutParams = LinearLayout.LayoutParams(dp(76f), dp(34f))
        }
        row.addView(col)
        row.addView(btn)
        parent.addView(row)
        return statusTv
    }

    private fun makeActionButton(label: String, bgHex: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            isAllCaps = false
            setPadding(dp(10f), 0, dp(10f), 0)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(8f).toFloat()
                setColor(Color.parseColor(bgHex))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun refreshStatus() {
        val hasOverlay = Settings.canDrawOverlays(this)
        setStatusStyle(overlayStatusTv, hasOverlay)

        val hasAcc = isAccessibilityEnabled()
        setStatusStyle(accStatusTv, hasAcc)

        val hasNotif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        setStatusStyle(notifStatusTv, hasNotif)

        refreshMissingMessages()
    }

    private fun setStatusStyle(tv: TextView, enabled: Boolean) {
        tv.text = if (enabled) "已开启" else "未开启"
        tv.setTextColor(
            if (enabled) Color.parseColor("#22C55E") else Color.parseColor("#F87171")
        )
    }

    private fun refreshMissingMessages() {
        missingContainer.removeAllViews()
        val msgs = AppPrefs.getMissingMessages(this)
        if (msgs.isEmpty()) {
            val empty = TextView(this).apply {
                text = "暂无未找到品种的记录"
                setTextColor(Color.parseColor("#64748B"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setPadding(0, dp(4f), 0, dp(4f))
            }
            missingContainer.addView(empty)
            return
        }

        for (msg in msgs) {
            val item = TextView(this).apply {
                text = msg
                setTextColor(Color.parseColor("#FCA5A5"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setPadding(dp(10f), dp(8f), dp(10f), dp(8f))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(8f).toFloat()
                    setColor(Color.parseColor("#2A181B"))
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dp(8f)
                }
            }
            missingContainer.addView(item)
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledList = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        val expectedId = "$packageName/${TvMarkerAccessibilityService::class.java.name}"
        return enabledList.any {
            it.id == expectedId || it.resolveInfo?.serviceInfo?.name == TvMarkerAccessibilityService::class.java.name
        }
    }
}
