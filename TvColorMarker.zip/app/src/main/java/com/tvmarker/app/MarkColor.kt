package com.tvmarker.app

enum class MarkColor(val cnName: String, val circleIndex: Int) {
    RED("红色", 0),
    BLUE("蓝色", 1)
}
