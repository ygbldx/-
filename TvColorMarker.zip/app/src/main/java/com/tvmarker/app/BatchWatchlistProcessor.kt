package com.tvmarker.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class BatchWatchlistProcessor(
    private val service: AccessibilityService,
    private val screenW: Int,
    private val screenH: Int
) {
    companion object {
        private const val POLL_MS = 40L
        private const val LONG_PRESS_MS = 520L
        private const val TAP_MS = 35L
        private const val SWIPE_MS = 165L
        private const val SETTLE_MS = 135L
        private const val MAX_SCROLLS_PER_DIR = 40

        // Calibrated from user's exact TradingView popup screenshot (1000105217.jpg)
        private const val RED_REL_X = 0.0893f
        private const val BLUE_REL_X = 0.2241f
    }

    data class BatchResult(
        val watchlistName: String,
        val completedCount: Int,
        val missingItems: Map<String, MarkColor>
    )

    suspend fun runBatch(tasks: Map<String, MarkColor>): BatchResult {
        if (tasks.isEmpty()) {
            return BatchResult("", 0, emptyMap())
        }

        // Wait briefly for watchlist rows to settle after user tapped bottom "自选表"
        waitUntil(maxMs = 800L) {
            val root = service.rootInActiveWindow
            root != null && SymbolExtractor.detectPage(root, screenH) == SymbolExtractor.TvPage.WATCHLIST
        }
        delay(80L)

        val watchlistName = SymbolExtractor.readCurrentWatchlistName(
            service.rootInActiveWindow,
            screenW,
            screenH
        )
        val remaining = LinkedHashMap(tasks)
        var completedCount = 0

        // Phase 1: Scan current screen + scroll DOWN to bottom
        completedCount += scanAndScrollDirection(remaining, scrollDown = true)

        // Phase 2: If still remaining, reverse and scroll UP to top
        if (remaining.isNotEmpty()) {
            completedCount += scanAndScrollDirection(remaining, scrollDown = false)
        }

        return BatchResult(
            watchlistName = watchlistName,
            completedCount = completedCount,
            missingItems = remaining
        )
    }

    private suspend fun scanAndScrollDirection(
        remaining: LinkedHashMap<String, MarkColor>,
        scrollDown: Boolean
    ): Int {
        var markedHere = 0
        var unchangedCount = 0
        var lastFingerprint = ""

        for (step in 0..MAX_SCROLLS_PER_DIR) {
            if (remaining.isEmpty()) break

            // Process ALL matching symbols currently visible on this screen in one pass
            while (remaining.isNotEmpty()) {
                val root = service.rootInActiveWindow ?: break
                val match = findFirstVisibleMatch(root, remaining) ?: break
                val (symbol, color, bounds) = match

                val ok = longPressAndSelectColor(bounds, color)
                if (ok) {
                    remaining.remove(symbol)
                    markedHere++
                } else {
                    // Dismiss any stray menu and avoid infinite retry on same stuck item
                    delay(120L)
                    break
                }
            }

            if (remaining.isEmpty()) break

            val rootBefore = service.rootInActiveWindow ?: break
            val currentFp = buildVisibleFingerprint(rootBefore)
            if (step > 0 && currentFp == lastFingerprint) {
                unchangedCount++
                if (unchangedCount >= 2) break
            } else {
                unchangedCount = 0
            }
            lastFingerprint = currentFp

            // Perform fast scroll
            val nativeScrolled = tryNativeScroll(rootBefore, scrollDown)
            if (nativeScrolled) {
                delay(SETTLE_MS)
            } else {
                val startY = if (scrollDown) screenH * 0.82f else screenH * 0.22f
                val endY = if (scrollDown) screenH * 0.20f else screenH * 0.84f
                val x = screenW * 0.50f
                dispatchSwipe(x, startY, x, endY, SWIPE_MS)
                delay(SETTLE_MS)
            }
        }
        return markedHere
    }

    private data class RowMatch(
        val symbol: String,
        val color: MarkColor,
        val bounds: Rect
    )

    private fun findFirstVisibleMatch(
        root: AccessibilityNodeInfo,
        remaining: Map<String, MarkColor>
    ): RowMatch? {
        val listTop = (screenH * 0.135f).toInt()
        val listBottom = (screenH * 0.915f).toInt()
        val leftMax = (screenW * 0.55f).toInt()
        val rect = Rect()
        var found: RowMatch? = null

        SymbolExtractor.traverse(root) { node ->
            if (found != null) return@traverse
            val text = node.text?.toString()?.trim()?.uppercase() ?: return@traverse
            val color = remaining[text] ?: return@traverse
            node.getBoundsInScreen(rect)
            if (rect.left < leftMax &&
                rect.centerY() in listTop..listBottom &&
                rect.width() > 0 && rect.height() > 0
            ) {
                found = RowMatch(text, color, Rect(rect))
            }
        }
        return found
    }

    private suspend fun longPressAndSelectColor(rowBounds: Rect, color: MarkColor): Boolean {
        val pressX = rowBounds.centerX().toFloat().coerceIn(screenW * 0.12f, screenW * 0.65f)
        val pressY = rowBounds.centerY().toFloat().coerceIn(screenH * 0.14f, screenH * 0.90f)

        dispatchLongPress(pressX, pressY, LONG_PRESS_MS)

        // Event-driven fast wait for popup menu ("移至底部" & "添加警报")
        val popupReady = waitUntil(maxMs = 1600L) {
            val r = service.rootInActiveWindow ?: return@waitUntil false
            findExactNode(r, "移至底部") != null && findExactNode(r, "添加警报") != null
        }
        if (!popupReady) return false

        val root = service.rootInActiveWindow ?: return false
        val targetPoint = locateColorCircle(root, color) ?: return false

        dispatchTap(targetPoint.first, targetPoint.second, TAP_MS)

        // Fast wait for popup to auto-close
        waitUntil(maxMs = 1000L) {
            val r = service.rootInActiveWindow ?: return@waitUntil true
            findExactNode(r, "移至底部") == null
        }
        delay(50L)
        return true
    }

    private fun locateColorCircle(
        root: AccessibilityNodeInfo,
        color: MarkColor
    ): Pair<Float, Float>? {
        val moveBottomNode = findExactNode(root, "移至底部") ?: return null
        val addAlertNode = findExactNode(root, "添加警报") ?: return null

        val rTop = Rect()
        val rBot = Rect()
        moveBottomNode.getBoundsInScreen(rTop)
        addAlertNode.getBoundsInScreen(rBot)

        val bandTop = rTop.bottom
        val bandBottom = rBot.top
        if (bandBottom <= bandTop) return null

        // 1. Primary: look for actual clickable circle nodes between "移至底部" and "添加警报"
        val circleNodes = mutableListOf<Rect>()
        val tmp = Rect()
        SymbolExtractor.traverse(root) { node ->
            if (!node.isClickable) return@traverse
            node.getBoundsInScreen(tmp)
            if (tmp.centerY() in bandTop..bandBottom &&
                tmp.width() in (screenW * 0.03f).toInt()..(screenW * 0.14f).toInt() &&
                tmp.height() in (screenW * 0.03f).toInt()..(screenW * 0.14f).toInt()
            ) {
                circleNodes.add(Rect(tmp))
            }
        }
        if (circleNodes.size >= 2) {
            circleNodes.sortBy { it.centerX() }
            val chosen = circleNodes.getOrNull(color.circleIndex)
            if (chosen != null) {
                return Pair(chosen.centerX().toFloat(), chosen.centerY().toFloat())
            }
        }

        // 2. Fallback: mathematically calibrated from user's exact TradingView popup layout
        val popupBounds = findPopupHorizontalBounds(moveBottomNode)
        val popupLeft = popupBounds.first
        val popupWidth = popupBounds.second
        val relX = if (color == MarkColor.RED) RED_REL_X else BLUE_REL_X
        val cx = popupLeft + popupWidth * relX
        val cy = (bandTop + bandBottom) / 2f
        return Pair(cx, cy)
    }

    private fun findPopupHorizontalBounds(anchor: AccessibilityNodeInfo): Pair<Float, Float> {
        val rect = Rect()
        var p: AccessibilityNodeInfo? = anchor
        var bestLeft = screenW * 0.0267f
        var bestWidth = screenW * 0.4922f
        var depth = 0
        while (p != null && depth < 5) {
            p.getBoundsInScreen(rect)
            if (rect.width() in (screenW * 0.38f).toInt()..(screenW * 0.65f).toInt()) {
                bestLeft = rect.left.toFloat()
                bestWidth = rect.width().toFloat()
            }
            p = p.parent
            depth++
        }
        return Pair(bestLeft, bestWidth)
    }

    private fun findExactNode(root: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val list = root.findAccessibilityNodeInfosByText(label) ?: return null
        return list.firstOrNull { it.text?.toString()?.trim() == label }
    }

    private fun tryNativeScroll(root: AccessibilityNodeInfo, scrollDown: Boolean): Boolean {
        val rect = Rect()
        var scrollable: AccessibilityNodeInfo? = null
        var maxArea = 0
        SymbolExtractor.traverse(root) { node ->
            if (!node.isScrollable) return@traverse
            node.getBoundsInScreen(rect)
            // Must be the vertical watchlist container (tall, not the thin top tab strip)
            if (rect.height() > (screenH * 0.45f).toInt()) {
                val area = rect.width() * rect.height()
                if (area > maxArea) {
                    maxArea = area
                    scrollable = node
                }
            }
        }
        val target = scrollable ?: return false
        val action = if (scrollDown) {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }
        return target.performAction(action)
    }

    private fun buildVisibleFingerprint(root: AccessibilityNodeInfo): String {
        val listTop = (screenH * 0.135f).toInt()
        val listBottom = (screenH * 0.915f).toInt()
        val leftMax = (screenW * 0.45f).toInt()
        val rect = Rect()
        val sb = StringBuilder()
        SymbolExtractor.traverse(root) { node ->
            val t = node.text?.toString()?.trim() ?: return@traverse
            if (t.isEmpty() || t.length > 24) return@traverse
            node.getBoundsInScreen(rect)
            if (rect.left < leftMax && rect.centerY() in listTop..listBottom) {
                sb.append(t).append('|')
            }
        }
        return sb.toString()
    }

    private suspend fun waitUntil(maxMs: Long, predicate: () -> Boolean): Boolean {
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < maxMs) {
            if (predicate()) return true
            delay(POLL_MS)
        }
        return predicate()
    }

    private suspend fun dispatchTap(x: Float, y: Float, durationMs: Long): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        return runGesture(GestureDescription.Builder().addStroke(stroke).build())
    }

    private suspend fun dispatchLongPress(x: Float, y: Float, durationMs: Long): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        return runGesture(GestureDescription.Builder().addStroke(stroke).build())
    }

    private suspend fun dispatchSwipe(
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float,
        durationMs: Long
    ): Boolean {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        return runGesture(GestureDescription.Builder().addStroke(stroke).build())
    }

    private suspend fun runGesture(gesture: GestureDescription): Boolean {
        return suspendCancellableCoroutine { cont ->
            val dispatched = service.dispatchGesture(
                gesture,
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(false)
                    }
                },
                null
            )
            if (!dispatched && cont.isActive) {
                cont.resume(false)
            }
        }
    }
}
