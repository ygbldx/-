package com.tvmarker.app

import android.content.Context
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AppPrefs {
    private const val PREF_NAME = "tv_color_marker_prefs"
    private const val KEY_BTN_X = "btn_x"
    private const val KEY_BTN_Y = "btn_y"
    private const val KEY_HAS_CUSTOM_POS = "has_custom_pos"
    private const val KEY_MISSING_MESSAGES = "missing_messages"

    fun saveButtonPos(context: Context, x: Int, y: Int) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_BTN_X, x)
            .putInt(KEY_BTN_Y, y)
            .putBoolean(KEY_HAS_CUSTOM_POS, true)
            .apply()
    }

    fun getButtonPos(context: Context): Pair<Int, Int>? {
        val sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        if (!sp.getBoolean(KEY_HAS_CUSTOM_POS, false)) return null
        return Pair(sp.getInt(KEY_BTN_X, 0), sp.getInt(KEY_BTN_Y, 0))
    }

    fun resetButtonPos(context: Context) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_BTN_X)
            .remove(KEY_BTN_Y)
            .putBoolean(KEY_HAS_CUSTOM_POS, false)
            .apply()
    }

    fun addMissingMessage(context: Context, message: String) {
        val sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val existing = getMissingMessages(context).toMutableList()
        val time = SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        existing.add(0, "[$time] $message")
        val trimmed = existing.take(100)
        val arr = JSONArray()
        trimmed.forEach { arr.put(it) }
        sp.edit().putString(KEY_MISSING_MESSAGES, arr.toString()).apply()
    }

    fun getMissingMessages(context: Context): List<String> {
        val sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val raw = sp.getString(KEY_MISSING_MESSAGES, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { idx -> arr.getString(idx) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun clearMissingMessages(context: Context) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_MISSING_MESSAGES)
            .apply()
    }
}
