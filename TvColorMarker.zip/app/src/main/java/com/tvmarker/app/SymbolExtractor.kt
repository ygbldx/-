package com.tvmarker.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityNodeInfo
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executor
import kotlin.coroutines.resume
import kotlin.math.abs

object SymbolExtractor {
    private val TIMEFRAME_REGEX = Regex(
        "^(\d+[秒分时日周月年天mhdwMyHDW]|1分钟|5分钟|15分钟|30分钟|1小时|4小时|1日|1周|2周|1月|3月|6月|1年)$"
    )
    private val SYMBOL_REGEX = Regex("^[A-Z0-9][A-Z0-9._!/-]{0,21}$")
    private val HEADER_SYMBOL_REGEX = Regex("^([A-Z0-9][A-Z0-9._!/-]{0,21})\s*[·•\u00B7]")

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    enum class TvPage {
        CHART,
        WATCHLIST,
        OTHER
    }

    fun detectPage(root: AccessibilityNodeInfo?, screenH: Int): TvPage {
        if (root == null) return TvPage.OTHER
        val chartTab = findBottomTab(root, "图表", screenH)
        val watchTab = findBottomTab(root, "自选表", screenH)
        if (chartTab == null || watchTab == null) return TvPage.OTHER

        // If the long-press popup is open on top, do not treat as chart page
        if (hasExactText(root, "移至底部") && hasExactText(root, "添加警报")) {
            return TvPage.WATCHLIST
        }

        if (isTabSelected(chartTab)) return TvPage.CHART
        if (isTabSelected(watchTab)) return TvPage.WATCHLIST

        // Fallback structural check if TV does not expose isSelected on tab
        if (hasExactText(root, "USD") || hasBottomWheel(root, screenH)) {
            return TvPage.CHART
        }
        return TvPage.OTHER
    }

    private fun findBottomTab(
        root: AccessibilityNodeInfo,
        label: String,
        screenH: Int
    ): AccessibilityNodeInfo? {
        val nodes = root.findAccessibilityNodeInfosByText(label) ?: return null
        val rect = Rect()
        for (n in nodes) {
            val txt = n.text?.toString()?.trim()
            val desc = n.contentDescription?.toString()?.trim()
            if (txt == label || desc == label) {
                n.getBoundsInScreen(rect)
                if (rect.top >= (screenH * 0.90f).toInt()) {
                    return n
                }
            }
        }
        return null
    }

    private fun isTabSelected(node: AccessibilityNodeInfo): Boolean {
        if (node.isSelected) return true
        var p = node.parent
        var depth = 0
        while (p != null && depth < 3) {
            if (p.isSelected) return true
            p = p.parent
            depth++
        }
        return false
    }

    private fun hasExactText(root: AccessibilityNodeInfo, text: String): Boolean {
        val list = root.findAccessibilityNodeInfosByText(text) ?: return false
        return list.any { it.text?.toString()?.trim() == text }
    }

    private fun hasBottomWheel(root: AccessibilityNodeInfo, screenH: Int): Boolean {
        val rect = Rect()
        var found = false
        traverse(root) { node ->
            if (found) return@traverse
            val t = node.text?.toString()?.trim() ?: return@traverse
            if (TIMEFRAME_REGEX.matches(t)) {
                node.getBoundsInScreen(rect)
                if (rect.top in (screenH * 0.89f).toInt()..(screenH * 0.96f).toInt()) {
                    found = true
                }
            }
        }
        return found
    }

    /**
     * Reads current symbol on Chart page in < 5ms via Accessibility nodes.
     */
    fun readChartSymbolFast(
        root: AccessibilityNodeInfo?,
        screenW: Int,
        screenH: Int
    ): String? {
        if (root == null) return null
        val rect = Rect()

        // 1. Primary: bottom-left native symbol wheel (x < 26% W, y in 90%..96% H)
        val wheelCenterY = (screenH * 0.935f).toInt()
        var bestWheelSymbol: String? = null
        var bestWheelDist = Int.MAX_VALUE

        // 2. Secondary: top-left header text ("GOLD · Gold · 1周 · TVC")
        var headerSymbol: String? = null

        traverse(root) { node ->
            val raw = node.text?.toString()?.trim()
            val desc = node.contentDescription?.toString()?.trim()
            val text = if (!raw.isNullOrEmpty()) raw else desc ?: return@traverse
            node.getBoundsInScreen(rect)
            if (rect.width() <= 0 || rect.height() <= 0) return@traverse

            // Check bottom-left wheel
            if (rect.left < (screenW * 0.24f).toInt() &&
                rect.centerY() in (screenH * 0.90f).toInt()..(screenH * 0.962f).toInt()
            ) {
                val upper = text.uppercase()
                if (isValidSymbolToken(upper)) {
                    val dist = abs(rect.centerY() - wheelCenterY)
                    if (dist < bestWheelDist) {
                        bestWheelDist = dist
                        bestWheelSymbol = upper
                    }
                }
            }

            // Check top-left header
            if (headerSymbol == null &&
                rect.left < (screenW * 0.55f).toInt() &&
                rect.top in (screenH * 0.025f).toInt()..(screenH * 0.10f).toInt()
            ) {
                val m = HEADER_SYMBOL_REGEX.find(text.uppercase())
                if (m != null) {
                    val candidate = m.groupValues[1]
                    if (isValidSymbolToken(candidate)) {
                        headerSymbol = candidate
                    }
                } else if (isValidSymbolToken(text.uppercase()) && rect.left < (screenW * 0.25f).toInt()) {
                    headerSymbol = text.uppercase()
                }
            }
        }

        return bestWheelSymbol ?: headerSymbol
    }

    /**
     * Fallback offline OCR via Android 11+ AccessibilityService.takeScreenshot().
     */
    suspend fun readChartSymbolByOcr(
        service: AccessibilityService,
        screenW: Int,
        screenH: Int
    ): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        val fullBitmap = takeScreenshotBitmap(service) ?: return null
        try {
            // Crop 1: Top-left chart title ("GOLD · Gold · 1周 · TVC")
            val topCrop = safeCrop(
                fullBitmap,
                0,
                (fullBitmap.height * 0.032f).toInt(),
                (fullBitmap.width * 0.65f).toInt(),
                (fullBitmap.height * 0.055f).toInt()
            )
            if (topCrop != null) {
                val text = runMlKitOcr(topCrop)
                topCrop.recycle()
                val sym = parseSymbolFromHeaderOcr(text)
                if (sym != null) return sym
            }

            // Crop 2: Bottom-left native wheel center line ("GOLD")
            val wheelCrop = safeCrop(
                fullBitmap,
                0,
                (fullBitmap.height * 0.922f).toInt(),
                (fullBitmap.width * 0.23f).toInt(),
                (fullBitmap.height * 0.030f).toInt()
            )
            if (wheelCrop != null) {
                val text = runMlKitOcr(wheelCrop)
                wheelCrop.recycle()
                val sym = parseSymbolFromWheelOcr(text)
                if (sym != null) return sym
            }
            return null
        } finally {
            fullBitmap.recycle()
        }
    }

    fun readCurrentWatchlistName(
        root: AccessibilityNodeInfo?,
        screenW: Int,
        screenH: Int
    ): String {
        if (root == null) return "当前"
        val rect = Rect()
        var selectedName: String? = null
        var fallbackName: String? = null

        traverse(root) { node ->
            val t = node.text?.toString()?.trim() ?: return@traverse
            if (t.isEmpty() || t.length > 24) return@traverse
            node.getBoundsInScreen(rect)
            // Top horizontal watchlist tab bar sits around y = 6.5% .. 13.0% of screen height
            if (rect.top >= (screenH * 0.06f).toInt() &&
                rect.bottom <= (screenH * 0.135f).toInt() &&
                rect.left >= (screenW * 0.08f).toInt()
            ) {
                if (isTabSelected(node)) {
                    selectedName = t
                } else if (fallbackName == null) {
                    fallbackName = t
                }
            }
        }
        return selectedName ?: fallbackName ?: "当前"
    }

    private fun isValidSymbolToken(token: String): Boolean {
        if (token.isEmpty() || token.length > 22) return false
        if (token == "USD" || token == "CNY" || token == "EUR" || token == "TV") return false
        if (TIMEFRAME_REGEX.matches(token)) return false
        // Must contain at least one letter or be a numeric stock code (>= 4 digits)
        val hasLetter = token.any { it in 'A'..'Z' }
        val isStockDigits = token.all { it.isDigit() } && token.length >= 4
        if (!hasLetter && !isStockDigits) return false
        return SYMBOL_REGEX.matches(token)
    }

    private fun parseSymbolFromHeaderOcr(ocrText: String): String? {
        if (ocrText.isBlank()) return null
        val cleaned = ocrText.replace('\n', ' ').trim().uppercase()
        val m = HEADER_SYMBOL_REGEX.find(cleaned)
        if (m != null && isValidSymbolToken(m.groupValues[1])) {
            return m.groupValues[1]
        }
        val tokens = cleaned.split(Regex("[\s·•,]+"))
        for (tok in tokens) {
            if (isValidSymbolToken(tok)) return tok
        }
        return null
    }

    private fun parseSymbolFromWheelOcr(ocrText: String): String? {
        if (ocrText.isBlank()) return null
        val tokens = ocrText.uppercase().split(Regex("[\s]+"))
        for (tok in tokens) {
            if (isValidSymbolToken(tok)) return tok
        }
        return null
    }

    private fun safeCrop(src: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap? {
        val sx = x.coerceIn(0, src.width - 1)
        val sy = y.coerceIn(0, src.height - 1)
        val sw = w.coerceAtMost(src.width - sx)
        val sh = h.coerceAtMost(src.height - sy)
        if (sw <= 4 || sh <= 4) return null
        return Bitmap.createBitmap(src, sx, sy, sw, sh)
    }

    private suspend fun takeScreenshotBitmap(service: AccessibilityService): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return suspendCancellableCoroutine { cont ->
            val directExecutor = Executor { runnable -> runnable.run() }
            try {
                service.takeScreenshot(
                    Display.DEFAULT_DISPLAY,
                    directExecutor,
                    object : AccessibilityService.TakeScreenshotCallback {
                        override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                            try {
                                val hw = Bitmap.wrapHardwareBuffer(
                                    result.hardwareBuffer,
                                    result.colorSpace
                                )
                                val sw = hw?.copy(Bitmap.Config.ARGB_8888, false)
                                result.hardwareBuffer.close()
                                hw?.recycle()
                                if (cont.isActive) cont.resume(sw)
                            } catch (_: Exception) {
                                if (cont.isActive) cont.resume(null)
                            }
                        }

                        override fun onFailure(errorCode: Int) {
                            if (cont.isActive) cont.resume(null)
                        }
                    }
                )
            } catch (_: Exception) {
                if (cont.isActive) cont.resume(null)
            }
        }
    }

    private suspend fun runMlKitOcr(bitmap: Bitmap): String {
        return suspendCancellableCoroutine { cont ->
            val image = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    if (cont.isActive) cont.resume(visionText.text ?: "")
                }
                .addOnFailureListener {
                    if (cont.isActive) cont.resume("")
                }
        }
    }

    fun traverse(root: AccessibilityNodeInfo?, visitor: (AccessibilityNodeInfo) -> Unit) {
        if (root == null) return
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.addLast(root)
        while (stack.isNotEmpty()) {
            val node = stack.removeLast()
            visitor(node)
            val count = node.childCount
            for (i in count - 1 downTo 0) {
                val child = node.getChild(i)
                if (child != null) stack.addLast(child)
            }
        }
    }
}
