package com.tvmarker.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class OverlayController(
    private val context: Context,
    private val onColorTap: (MarkColor) -> Unit
) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var buttonContainer: LinearLayout? = null
    private var buttonParams: WindowManager.LayoutParams? = null
    private var redBtn: View? = null
    private var blueBtn: View? = null
    private var feedbackText: TextView? = null
    private var isButtonsVisible = false

    private var doneOverlay: View? = null
    private val hideDoneRunnable = Runnable { hideDoneBanner() }
    private val hideFeedbackRunnable = Runnable { feedbackText?.visibility = View.GONE }

    private val screenW: Int
    private val screenH: Int

    init {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels
    }

    fun getScreenSize(): Pair<Int, Int> = Pair(screenW, screenH)

    private fun dp(value: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, context.resources.displayMetrics).toInt()

    fun showButtons() {
        mainHandler.post {
            if (buttonContainer == null) {
                createButtonsView()
            }
            if (!isButtonsVisible && buttonContainer != null && buttonParams != null) {
                try {
                    wm.addView(buttonContainer, buttonParams)
                    isButtonsVisible = true
                } catch (_: Exception) {
                }
            }
        }
    }

    fun hideButtons() {
        mainHandler.post {
            if (isButtonsVisible && buttonContainer != null) {
                try {
                    wm.removeView(buttonContainer)
                } catch (_: Exception) {
                }
                isButtonsVisible = false
            }
        }
    }

    fun reloadDefaultPosition() {
        mainHandler.post {
            val params = buttonParams ?: return@post
            val (defX, defY) = computeDefaultTvLogoPos()
            params.x = defX
            params.y = defY
            if (isButtonsVisible && buttonContainer != null) {
                try {
                    wm.updateViewLayout(buttonContainer, params)
                } catch (_: Exception) {
                }
            }
        }
    }

    /**
     * Updates lit/dim state of the Red & Blue circles based on current symbol's recorded color.
     * null -> both dim; RED -> red lit; BLUE -> blue lit.
     */
    fun updateLitState(activeColor: MarkColor?, animate: Boolean = false) {
        mainHandler.post {
            val redLit = activeColor == MarkColor.RED
            val blueLit = activeColor == MarkColor.BLUE
            redBtn?.background = buildCircleDrawable(
                fillColor = if (redLit) Color.parseColor("#FF2442") else Color.parseColor("#7A1F28"),
                lit = redLit
            )
            blueBtn?.background = buildCircleDrawable(
                fillColor = if (blueLit) Color.parseColor("#1E88FF") else Color.parseColor("#1A3566"),
                lit = blueLit
            )
            if (animate && activeColor != null) {
                val target = if (activeColor == MarkColor.RED) redBtn else blueBtn
                target?.animate()?.cancel()
                target?.scaleX = 1.24f
                target?.scaleY = 1.24f
                target?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(140)?.start()
            }
        }
    }

    fun showMiniFeedback(message: String, isError: Boolean = false) {
        mainHandler.post {
            val tv = feedbackText ?: return@post
            tv.text = message
            tv.setTextColor(if (isError) Color.parseColor("#FCA5A5") else Color.WHITE)
            tv.visibility = View.VISIBLE
            mainHandler.removeCallbacks(hideFeedbackRunnable)
            mainHandler.postDelayed(hideFeedbackRunnable, 1100L)
        }
    }

    fun vibrateShort(doublePulse: Boolean = false) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (!vibrator.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (doublePulse) {
                    vibrator.vibrate(
                        VibrationEffect.createWaveform(longArrayOf(0, 35, 55, 35), -1)
                    )
                } else {
                    vibrator.vibrate(VibrationEffect.createOneShot(28, VibrationEffect.DEFAULT_AMPLITUDE))
                }
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(if (doublePulse) 80 else 28)
            }
        } catch (_: Exception) {
        }
    }

    /**
     * Shows a huge "完活" banner in screen center.
     * Dismisses IMMEDIATELY on any screen touch (inside or outside) without consuming outside touches,
     * or auto-dismisses after 10 seconds.
     */
    @SuppressLint("ClickableViewAccessibility")
    fun showDoneBanner() {
        mainHandler.post {
            hideDoneBannerInternal()

            val tv = TextView(context).apply {
                text = "完活"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 64f)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(36f), dp(22f), dp(36f), dp(22f))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(22f).toFloat()
                    setColor(Color.parseColor("#E614191F"))
                    setStroke(dp(3f), Color.parseColor("#22C55E"))
                }
                elevation = dp(12f).toFloat()
            }

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
            }

            tv.setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_DOWN ||
                    event.action == MotionEvent.ACTION_OUTSIDE
                ) {
                    hideDoneBannerInternal()
                }
                false
            }

            try {
                wm.addView(tv, params)
                doneOverlay = tv
                mainHandler.removeCallbacks(hideDoneRunnable)
                mainHandler.postDelayed(hideDoneRunnable, 10_000L)
            } catch (_: Exception) {
            }
        }
    }

    fun hideDoneBanner() {
        mainHandler.post { hideDoneBannerInternal() }
    }

    private fun hideDoneBannerInternal() {
        mainHandler.removeCallbacks(hideDoneRunnable)
        doneOverlay?.let { view ->
            try {
                wm.removeView(view)
            } catch (_: Exception) {
            }
        }
        doneOverlay = null
    }

    fun destroy() {
        hideButtons()
        hideDoneBanner()
    }

    private fun computeDefaultTvLogoPos(): Pair<Int, Int> {
        // Calibrated to vivo Y300t TradingView standard screenshot:
        // White TV logo center is at x = 4.23% W, y = 88.75% H.
        // Circle diameter = 28dp (radius = 14dp), feedback pill above takes ~20dp.
        val radiusPx = dp(14f)
        val topExtraPx = dp(20f)
        val x = (screenW * 0.0423f).toInt() - radiusPx
        val y = (screenH * 0.8875f).toInt() - radiusPx - topExtraPx
        return Pair(x.coerceAtLeast(0), y.coerceAtLeast(0))
    }

    private fun buildCircleDrawable(fillColor: Int, lit: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fillColor)
            if (lit) {
                setStroke(dp(2.5f), Color.WHITE)
            } else {
                setStroke(dp(1f), Color.parseColor("#44FFFFFF"))
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createButtonsView() {
        val circlePx = dp(28f)
        val gapPx = dp(6f)

        val rootLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.START
        }

        val tip = TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            setTextColor(Color.WHITE)
            setPadding(dp(6f), dp(2f), dp(6f), dp(2f))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(6f).toFloat()
                setColor(Color.parseColor("#CC0F172A"))
            }
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                dp(18f)
            ).apply {
                bottomMargin = dp(2f)
            }
        }
        feedbackText = tip
        rootLayout.addView(tip)

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val red = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(circlePx, circlePx)
            background = buildCircleDrawable(Color.parseColor("#7A1F28"), false)
        }

        val blue = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(circlePx, circlePx).apply {
                marginStart = gapPx
            }
            background = buildCircleDrawable(Color.parseColor("#1A3566"), false)
        }

        redBtn = red
        blueBtn = blue
        row.addView(red)
        row.addView(blue)
        rootLayout.addView(row)

        val savedPos = AppPrefs.getButtonPos(context) ?: computeDefaultTvLogoPos()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedPos.first
            y = savedPos.second
        }

        attachTapAndLongPressDrag(red, MarkColor.RED, params, rootLayout)
        attachTapAndLongPressDrag(blue, MarkColor.BLUE, params, rootLayout)

        buttonContainer = rootLayout
        buttonParams = params
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachTapAndLongPressDrag(
        target: View,
        color: MarkColor,
        params: WindowManager.LayoutParams,
        container: View
    ) {
        val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
        var downRawX = 0f
        var downRawY = 0f
        var startParamX = 0
        var startParamY = 0
        var dragEnabled = false
        var moved = false

        val enableDragRunnable = Runnable {
            dragEnabled = true
            vibrateShort(false)
            showMiniFeedback("拖动调整位置")
        }

        target.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startParamX = params.x
                    startParamY = params.y
                    dragEnabled = false
                    moved = false
                    mainHandler.postDelayed(enableDragRunnable, 340L)
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (!dragEnabled && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                        mainHandler.removeCallbacks(enableDragRunnable)
                        moved = true
                    }
                    if (dragEnabled) {
                        moved = true
                        params.x = (startParamX + dx.toInt()).coerceIn(0, screenW - dp(66f))
                        params.y = (startParamY + dy.toInt()).coerceIn(0, screenH - dp(50f))
                        try {
                            wm.updateViewLayout(container, params)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(enableDragRunnable)
                    if (dragEnabled) {
                        AppPrefs.saveButtonPos(context, params.x, params.y)
                    } else if (!moved && event.actionMasked == MotionEvent.ACTION_UP) {
                        onColorTap(color)
                    }
                    dragEnabled = false
                    true
                }

                else -> false
            }
        }
    }
}
