package com.tvmarker.app

import android.accessibilityservice.AccessibilityService
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

class TvMarkerAccessibilityService : AccessibilityService() {

    companion object {
        private const val TV_PACKAGE = "com.tradingview.tradingviewapp"

        @Volatile
        var instance: TvMarkerAccessibilityService? = null
            private set
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var overlay: OverlayController
    private lateinit var processor: BatchWatchlistProcessor

    // Queued symbols for the current watchlist batch: Symbol -> Last Selected Color
    private val pendingQueue = ConcurrentHashMap<String, MarkColor>()

    @Volatile
    private var isBatchRunning = false

    @Volatile
    private var lastObservedChartSymbol: String? = null

    private var evaluateJob: Job? = null
    private var tapJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        NotificationHelper.ensureChannel(this)
        overlay = OverlayController(this) { color -> handleColorButtonTap(color) }
        val (w, h) = overlay.getScreenSize()
        processor = BatchWatchlistProcessor(this, w, h)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString()
        if (pkg != null && pkg != TV_PACKAGE) {
            if (!isBatchRunning) {
                overlay.hideButtons()
            }
            return
        }

        // Fast debounce to avoid redundant tree traversals
        evaluateJob?.cancel()
        evaluateJob = scope.launch {
            delay(35L)
            evaluateCurrentScreen()
        }
    }

    override fun onInterrupt() {
        overlay.hideButtons()
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        scope.cancel()
        if (::overlay.isInitialized) {
            overlay.destroy()
        }
    }

    fun resetFloatingButtonsToDefault() {
        if (::overlay.isInitialized) {
            overlay.reloadDefaultPosition()
        }
    }

    private fun evaluateCurrentScreen() {
        if (isBatchRunning) return
        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString()
        if (pkg != TV_PACKAGE) {
            overlay.hideButtons()
            return
        }

        val (w, h) = overlay.getScreenSize()
        when (SymbolExtractor.detectPage(root, h)) {
            SymbolExtractor.TvPage.CHART -> {
                if (Settings.canDrawOverlays(this)) {
                    overlay.showButtons()
                    val currentSymbol = SymbolExtractor.readChartSymbolFast(root, w, h)
                    if (currentSymbol != null && currentSymbol != lastObservedChartSymbol) {
                        lastObservedChartSymbol = currentSymbol
                        overlay.updateLitState(pendingQueue[currentSymbol], animate = false)
                    } else if (currentSymbol != null) {
                        overlay.updateLitState(pendingQueue[currentSymbol], animate = false)
                    } else {
                        overlay.updateLitState(null, animate = false)
                    }
                }
            }

            SymbolExtractor.TvPage.WATCHLIST -> {
                overlay.hideButtons()
                // Strict rule: if user selected NO symbols, do absolutely nothing!
                if (pendingQueue.isNotEmpty() && !isBatchRunning) {
                    launchBatchProcessing()
                }
            }

            SymbolExtractor.TvPage.OTHER -> {
                overlay.hideButtons()
            }
        }
    }

    private fun handleColorButtonTap(color: MarkColor) {
        if (isBatchRunning) return
        tapJob?.cancel()
        tapJob = scope.launch {
            val (w, h) = overlay.getScreenSize()
            val root = rootInActiveWindow
            var symbol = SymbolExtractor.readChartSymbolFast(root, w, h)
            if (symbol == null) {
                symbol = SymbolExtractor.readChartSymbolByOcr(this@TvMarkerAccessibilityService, w, h)
            }

            if (symbol == null) {
                // Strict rule: if symbol could not be read, DO NOT light up!
                overlay.updateLitState(null, animate = false)
                overlay.vibrateShort(doublePulse = true)
                overlay.showMiniFeedback("未读到品种", isError = true)
                return@launch
            }

            // Same symbol tapped multiple times -> last selected color wins, counted once
            pendingQueue[symbol] = color
            lastObservedChartSymbol = symbol

            overlay.updateLitState(color, animate = true)
            overlay.vibrateShort(doublePulse = false)
            val label = if (color == MarkColor.RED) "红" else "蓝"
            overlay.showMiniFeedback("${label}: $symbol (${pendingQueue.size})")
        }
    }

    private fun launchBatchProcessing() {
        isBatchRunning = true
        val snapshot = LinkedHashMap<String, MarkColor>()
        pendingQueue.forEach { (k, v) -> snapshot[k] = v }
        pendingQueue.clear()
        lastObservedChartSymbol = null

        scope.launch {
            try {
                val result = processor.runBatch(snapshot)

                // Notify & persist any symbols not found in the watchlist
                for ((missingSymbol, color) in result.missingItems) {
                    NotificationHelper.notifyMissingSymbol(
                        context = this@TvMarkerAccessibilityService,
                        symbol = missingSymbol,
                        color = color,
                        watchlistName = result.watchlistName
                    )
                }

                // Immediately show huge "完活" overlay (dismisses on any touch or after 10s)
                if (Settings.canDrawOverlays(this@TvMarkerAccessibilityService)) {
                    overlay.showDoneBanner()
                }
                overlay.vibrateShort(doublePulse = true)
            } finally {
                isBatchRunning = false
            }
        }
    }
}
